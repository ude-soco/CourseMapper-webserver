import pandas as pd
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy as shc
import OptimumClusters as oc
from sklearn.preprocessing import StandardScaler, normalize
from sklearn.cluster import AgglomerativeClustering

#df=pd.read_csv('output.csv', usecols=['stdId','totalSessions','totalActivities','totalAnnotations'],index_col=0)
df=pd.read_csv('activitiesProduction.csv', usecols=['stdId','totalSessions','totalAccesses','pdfAccess','videoAccess','totalEnrollments','totalActivities','totalAnnotations','totalLikesOnAnnotations','likesOnRepliesOfAnnotations','totalDislikes','dislikesOnRepliesOfAnnotations', 'videosStarted','videosCompleted','videosPlayed','videosPaused','pdfStarted','pdfCompleted','slidesViewed'],index_col=0)
print(df)

# remove NAN
#df.dropna(inplace=True)

# Scaling the data by choosing the columns we want to scale (Scalar Transform)
print(df.describe())

scaler = StandardScaler()

data_scaled=normalize(df)

df[['totalSessions_T','totalActivities_T','totalAnnotations_T']]= scaler.fit_transform(df[['totalSessions','totalActivities','totalAnnotations']])
print(df)
print((df.describe()))




plt.figure(figsize=(10,7))
plt.title("Dendrograms Standard Scaler")
dendD = shc.dendrogram(shc.linkage(df[['totalSessions_T','totalActivities_T','totalAnnotations_T']],method='ward'))
plt.show()

plt.figure(figsize=(10,7))
plt.title("Dendrograms Normalized Data")
dendS = shc.dendrogram(shc.linkage(data_scaled,method='ward'))
plt.show()

oc.silhouetteScore(df,AgglomerativeClustering(linkage='ward'))
