from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans,AgglomerativeClustering


# Using features finalized from correlation
df = pd.read_csv('activitiesProduction.csv', usecols=['stdUsername','totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'])


scaler = StandardScaler()
df_scaled = scaler.fit_transform(df.drop('stdUsername',axis=1))


# Create a t-SNE instance with perplexity=10
tsne = TSNE(n_components=2, perplexity=18)

# Fit and transform the data to the 2D t-SNE representation
tsne_data = tsne.fit_transform(df_scaled)
print(type(tsne_data))

tsneDf = pd.DataFrame(tsne_data,columns=['x_tsne','y_tsne'])
kmeans = KMeans(n_clusters=3)
kmeans.fit(df_scaled)
df['km_clusters'] = kmeans.labels_
tsneDf['stdUsername']= df['stdUsername']


kmeansOnTsne = KMeans(n_clusters=3)
kmeansOnTsne.fit(tsneDf[['x_tsne','y_tsne']])
tsneDf['tsne_clusters_km']=kmeansOnTsne.labels_
plt.figure(figsize=(15,9))
plt.scatter(tsneDf['x_tsne'],tsneDf['y_tsne'],c=tsneDf['tsne_clusters_km'])
plt.xlabel('t-SNE Feature X')
plt.ylabel('t-SNE Feature Y')
plt.title('KMeans Clustering on Reduced Dimensions by t-SNE - k=3')
# Show the plot
plt.savefig('KMeans_on t-SNE Dimensions.png')
plt.show()
print(tsneDf)
# Creating a graph calculating the Silhouette Score on the data to find optimal number of clusters b/w 1 to 10
print('Silhouette Score KMeans with t-SNE',silhouette_score(tsneDf[['x_tsne','y_tsne']],tsneDf['tsne_clusters_km']))
hacOnTsne = AgglomerativeClustering(n_clusters=3)
hacOnTsne.fit(tsneDf[['x_tsne','y_tsne']])
tsneDf['tsne_clusters_hac']=hacOnTsne.labels_
plt.figure(figsize=(15,9))
plt.scatter(tsneDf['x_tsne'],tsneDf['y_tsne'],c=tsneDf['tsne_clusters_hac'])
plt.xlabel('t-SNE Feature X')
plt.ylabel('t-SNE Feature Y')
plt.title('HAC Clustering on Reduced Dimensions by t-SNE - k=3')
# Show the plot
plt.savefig('HAC_on t-SNE Dimensions.png')
plt.show()
print('Silhouette Score HAC with t-SNE',silhouette_score(tsneDf[['x_tsne','y_tsne']],tsneDf['tsne_clusters_hac']))
mergedTsneKmeansDf = pd.merge(df,tsneDf, on='stdUsername')
mergedTsneKmeansDf.to_csv('MergedTsneKMClusters.csv')
print(mergedTsneKmeansDf[['stdUsername','tsne_clusters_km', 'km_clusters']])





# Plot the t-SNE embedding
plt.figure(figsize=(15,9))
plt.scatter(tsne_data[:, 0], tsne_data[:, 1])
plt.title("t-SNE Visualization")
plt.xlabel("t-SNE Dimension 1")
plt.ylabel("t-SNE Dimension 2")
plt.savefig('t-SNE Scatter Plot.png')
plt.show()

