import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler


# Computing the correlation matrix
def correlation_matrix():
    df=pd.read_csv('activitiesProduction.csv')
    df=df.drop(['stdId','stdUsername','timeSpentOnVideos'],axis=1)
    print(df)
    
    cor_matrix = df.corr()
    cor_matrix.to_csv('correlationAllNumFeatures.csv')
    print(cor_matrix)
    return cor_matrix


def scatterPlotTotAct():
    scaler = StandardScaler()
    df=pd.read_csv('activitiesProduction.csv', usecols=['totalActivities'], index_col=None)
    df_normalized=pd.read_csv('activitiesProduction.csv', usecols=['totalActivities'], index_col=None)

    df_scaled=scaler.fit_transform(df[['totalActivities']])
    print(df_normalized)
    #df['Sr'] = range(len(df))
    df_normalized['Sr'] = range(len(df))
    df['Sr'] = range(len(df))
    #print(df['Sr'])
    #print(list(df.index.values))
    #print(df.totalActivities)
    plt.figure(figsize=(15,10))
    plt.scatter(df['Sr'],df['totalActivities'])
    plt.xlabel('Students',fontsize=10)
    plt.ylabel('Total Activities',fontsize=10)
    plt.title('Scatter Plot of Student Activities',fontsize=15)
    plt.savefig('ev_scatterplot_totAct.png')
    plt.show()



def correlation_PC():
    df = pd.read_csv('questionnaireResults.csv')
    corr_matrix = df.drop('stdUsername',axis=1).corr()
    corr_matrix.to_csv('PC_Correlation.csv')
    return corr_matrix



def correlation_pc_act():
    df_act_pc = pd.read_csv('mergedPC_Activities.csv')
    corr_matrix = df_act_pc.drop('stdUsername',axis=1).corr()
    corr_matrix.to_csv('CorrelationPC_Act.csv')
    return corr_matrix



#scatterPlotTotAct()
correlation_matrix()
#correlation_PC()
#correlation_pc_act()