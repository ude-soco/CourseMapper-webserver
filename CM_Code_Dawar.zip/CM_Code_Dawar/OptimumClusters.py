import pandas as pd
from yellowbrick.cluster import KElbowVisualizer
from sklearn.metrics.cluster import calinski_harabasz_score
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.preprocessing import StandardScaler
import scipy.cluster.hierarchy as shc
import matplotlib.pyplot as plt


def silhouetteScore(df,model):
    visualizer = KElbowVisualizer(model,k=(2,10), metric='silhouette',timings=True)
    visualizer.fit(df)
    visualizer.show()

def calinskiScore():
    hac_CI = []
    km_CI = []
    k=10
    scaler = StandardScaler()
    
    df=pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'])
    scaled_df=scaler.fit_transform(df)
    for k in range(2,k+1):
        kmeans = KMeans(n_clusters=k).fit(scaled_df)
        k_labels = kmeans.labels_
        hac = AgglomerativeClustering(n_clusters=k,linkage='ward').fit(scaled_df)
        h_labels = hac.labels_
        km_CI.append(calinski_harabasz_score(scaled_df,k_labels))
        hac_CI.append(calinski_harabasz_score(scaled_df,h_labels))
    #kmeans.fit(scaled_df)
    #df['km_clusters']=kmeans.labels_
    #hac.fit(scaled_df)
    #df['hac_clusters']=hac.labels_
    #km_cal_score = calinski_harabasz_score(scaled_df,kmeans.labels_)
    #hac_cal_score = calinski_harabasz_score(scaled_df,hac.labels_)
    print('Calinski-Harabsz Index for K-Means',km_CI)
    print('Calinski-Harabsz Index for HAC',hac_CI)
    #cs = calinski_harabasz_score(df, labels)
    #print(cs)
    #return hac_CI
    return km_CI

def silhoutteCoefficientKM():
    scaler = StandardScaler()
    df=pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],index_col=None)
    df_normalized=scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    k=10
    sil = []
    for k in range(2,k+1):
        kmeans = KMeans(n_clusters=k).fit(df_normalized)
        labels = kmeans.labels_
        sil.append(silhouette_score(df_normalized,labels,metric='euclidean'))
    print(sil)
    return sil
    
def silhoutteCoefficientHAC():
    scaler = StandardScaler()
    df=pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],index_col=None)
    df_normalized=scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    k=10
    sil = []
    for k in range(2,k+1):
        hac = AgglomerativeClustering(linkage='complete',n_clusters=k).fit(df_normalized)
        labels = hac.labels_
        sil.append(silhouette_score(df_normalized,labels,metric='euclidean'))
    print(sil)
    return sil



def createPlot():
    #scaler = StandardScaler()
    #df=pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalAccesses','pdfAccess','videoAccess','totalEnrollments','totalActivities','totalAnnotations','totalLikesOnAnnotations','likesOnRepliesOfAnnotations','totalDislikes','dislikesOnRepliesOfAnnotations', 'videosStarted','videosCompleted','videosPlayed','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],index_col=None)
    #df_normalized=scaler.fit_transform(df[['totalSessions','totalAccesses','pdfAccess','videoAccess','totalEnrollments','totalActivities','totalAnnotations','totalLikesOnAnnotations','likesOnRepliesOfAnnotations','totalDislikes','dislikesOnRepliesOfAnnotations', 'videosStarted','videosCompleted','videosPlayed','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    fig=plt.figure(figsize=(19,11))
    ax = fig.add_subplot(1,1,1)
    ax.tick_params(axis='both',which='major',labelsize=20)
    #ax.plot(silhoutteCoefficientKM())
    #ax.plot(silhoutteCoefficientHAC())
    ax.plot(calinskiScore())
    #ax.plot(davies_bouldin_KM())
    #ax.plot(davies_bouldin_HAC())
    ax.set_xlabel('Number of Clusters',fontsize=20)
    ax.set_ylabel('CH-Index ',fontsize=20)
    ax.set_title('CH-Index - KMeans',fontsize=25)
    #plt.savefig('SI_KM.png')
    plt.show()


def createDendrogram():
    
    scaler = StandardScaler()
    df=pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],index_col=None)
    df_normalized=scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    plt.figure(figsize=(16,12))
    shc.dendrogram(shc.linkage(df_normalized,method='ward',metric='euclidean'))
    
    plt.title('Dendrogram of HAC using ward linkage',fontsize=20)
    
    plt.xlabel('Students',fontsize=15)
    plt.ylabel('Closeness/ Height',fontsize=15)
    plt.savefig('ev_Dendrogram.png')
    plt.show()
    

def davies_bouldin_KM():
    scaler = StandardScaler()
    df=pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],index_col=None)
    df_normalized=scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    k=10
    db = []
    for k in range(2,k+1):
        kmeans = KMeans(n_clusters=k).fit(df_normalized)
        labels = kmeans.labels_
        db.append(davies_bouldin_score(df_normalized,labels))
    print(db)
    return db
    
def davies_bouldin_HAC():
    scaler = StandardScaler()
    df=pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],index_col=None)
    df_normalized=scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    k=10
    db = []
    for k in range(2,k+1):
        hac = AgglomerativeClustering(linkage='ward',n_clusters=k).fit(df_normalized)
        labels = hac.labels_
        db.append(davies_bouldin_score(df_normalized,labels))
    print(db)
    return db

createPlot()
#createDendrogram()
#calinskiScore()