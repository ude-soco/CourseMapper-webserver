from matplotlib import pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans
import seaborn as sns


plotDataFrame = pd.read_csv('output1.csv', usecols=['totalSessions','totalActivities','totalAnnotations'])
#print(plotDataFrame)
kmeans = KMeans(n_clusters=2)
kmeans.fit(plotDataFrame)
plotDataFrame['clusters']=kmeans.labels_
print(plotDataFrame)
tPlotDataFrame= plotDataFrame.transpose()
print(tPlotDataFrame)
meandf = plotDataFrame.groupby('clusters').mean()
sddf = plotDataFrame.groupby('clusters').std()
print(meandf)

#print(sddf)
sns.boxplot(data=plotDataFrame[['totalSessions', 'totalActivities', 'totalAnnotations']], hue='clusters',x='', y='') # THIS IS THE X AND Y I WAS TALKING ABOUT
plt.xlabel("Activities")
plt.ylabel("Counts")
plt.show()



# IGNORE THE CODE BELOW
""" # initialize figure with 4 subplots in a row
fig, ax = plt.subplots(1, 3, figsize=(10, 6))

# add padding between the subplots
plt.subplots_adjust(wspace=0.5) 

# draw boxplot for age in the 1st subplot
sns.boxplot(data=plotDataFrame['totalSessions'], ax=ax[0], color='brown',)
ax[0].set_xlabel('Sessions')

# draw boxplot for station_distance in the 2nd subplot
sns.boxplot(data=plotDataFrame['totalActivities'], ax=ax[1], color='g')
ax[1].set_xlabel('Activities')

# draw boxplot for stores_count in the 3rd subplot
sns.boxplot(data=plotDataFrame['totalAnnotations'], ax=ax[2], color='y')
ax[2].set_xlabel('Annotations')

# by default, you'll see x-tick label set to 0 in each subplot
# remove it by setting it to empty list
for subplot in ax:
    subplot.set_xticklabels([])
    
plt.show()
#plotDataFrame.plot(kind='bar',stacked=False)
#plt.show() """