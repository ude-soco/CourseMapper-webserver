import numpy as np
from pymongo import MongoClient
from bson.json_util import dumps
import pandas as pd
import DataProcessing as dp
import populateStudentProfiles as stdProfiling
import JsonToCsvConversion as convertToCsv
import seaborn as sn
import matplotlib.pyplot as plt

import correlation as correlation

client = MongoClient("localhost", 27017)
db = client["coursemapper_v2"]
collection = db["activitiesProduction"]
activities = collection.find({})

listOfStudentActivityDict = dp.processActivities(collection)

# writing all the dictionaries created and populated in a json file
# Converting the JSON to CSV
stdProfiling.createProfiles(listOfStudentActivityDict)


# Correlation between activities
#correlation.correlation_matrix()
#allColumns=pd.read_csv('output.csv')
#print(allColumns)
#data = allColumns.drop(['stdId', 'stdUsername', 'totalSessionTime','avgSessionTime', 'maxSessionTime', 'minSessionTime'], axis=1)
#print(data)
#dataframe = pd.DataFrame(data)
#print(dataframe)
#corr_matrix= dataframe.corr().round(4) # Round to 3 decimal places
#print(type(corr_matrix))
#print(corr_matrix.to_latex(index=False)) # Convert the dataframe to latex table
#corr_matrix_unstacked= corr_matrix.unstack()
#print(corr_matrix_unstacked[abs(corr_matrix_unstacked) >= 0.7]) # Strong negative correlation
#print(corr_matrix_unstacked[corr_matrix_unstacked >  0.7]) # Strong positive correlation

#print(dataframe.describe())
#print(dataframe.totalSessions.corr(dataframe.totalActivities)) # Pair-wise correlation- between total sessions and total activities
#mask = np.triu(np.ones_like(dataframe.corr()))
#dataplot = sn.heatmap(dataframe.corr(), cmap="RdBu", annot=True, mask=mask)
#plt.show()
#print(dataplot)

#plt.figure(figsize=(30,15))
#sn.heatmap(corr_matrix,annot=True)
#plt.show()
# Correlation between PCs

# Correlation between activities and PCs




# Call the K-Means functions
# Call the Hierarchical clustering functions