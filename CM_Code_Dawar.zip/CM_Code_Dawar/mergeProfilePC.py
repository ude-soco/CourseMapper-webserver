from matplotlib import pyplot as plt
import pandas as pd
from sklearn.cluster import AgglomerativeClustering, KMeans
from sklearn.preprocessing import StandardScaler
import seaborn as sns
import numpy as np


def mergePC_Activities():

    scalar = StandardScaler()
    pcdf = pd.read_csv('questionnaireResults.csv') # Read csv file of Personal characteristics
    activitiesdf = pd.read_csv('activitiesProduction.csv',usecols=['stdUsername','totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']) # Read csv file of student profiles
    activitiesdf_scaled = scalar.fit_transform(activitiesdf.drop('stdUsername',axis=1))

    kmeans = KMeans(n_clusters=3)
    kmeans.fit(activitiesdf_scaled)
    activitiesdf['clusters']=kmeans.labels_

    hac = AgglomerativeClustering(n_clusters=3,linkage='ward')
    hac.fit_predict(activitiesdf_scaled)
    activitiesdf['hac_clusters']=hac.labels_
    #print(pc)
    #print(profiles)
    merged = pd.merge(activitiesdf,pcdf,on='stdUsername') # Merge both files on CourseMapper ID, This column name should be same in both files
    # Merging will ignore all those profiles, who haven't filled the questionnaire
    merged.to_csv('mergedPC_Activities.csv',index=False)
    
    PC_Cat_df = pd.read_csv('PC Categorized.csv') # Read csv file of student profiles
    clusterLabels_df = pd.DataFrame(merged[['stdUsername','clusters','hac_clusters']])
    mergedCatPC = pd.merge(clusterLabels_df,PC_Cat_df,on='stdUsername')
    mergedCatPC.to_csv('PC Categorized_clusterized.csv',index=False)
    print(mergedCatPC)



def comparePC_Clusters_BoxPlot(): # Creating grouped boxplot of means of PCs in each cluster (Kunkel et. al)
    plotDataFrame = pd.read_csv('mergedPC_Activities.csv')
    plotDataFrame = plotDataFrame.drop(columns=plotDataFrame[['stdUsername','hac_clusters','totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']],axis=1)
    print(plotDataFrame)
    # Melt the DataFrame to combine the three activity columns into a single column
    melted_df = pd.melt(plotDataFrame, id_vars=['clusters'], value_vars=plotDataFrame, var_name='Activity', value_name='Counts')
    #print(melted_df)
    # Plotting
    plt.figure(figsize=(15,11))
    sns.boxplot(data=melted_df, x='Counts', y='Activity', hue='clusters', orient='h')
    plt.xlabel("Counts")
    plt.ylabel("Activities")
    plt.show()

def means_sd_PCs_BarChart():
    plotDataFrame = pd.read_csv('mergedPC_Activities.csv')
    plotDataFrame = plotDataFrame.drop(columns=plotDataFrame[['stdUsername','hac_clusters','totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']],axis=1)
    print(type(plotDataFrame))
    means = plotDataFrame.drop('clusters',axis=1).mean().values

    stds = plotDataFrame.drop('clusters',axis=1).std().values

    df_plot = pd.DataFrame({'Means': means, 'Standard Deviation':stds},index=list(plotDataFrame.drop('clusters',axis=1)))
    df_plot.reset_index(inplace=True)
    melted_df = df_plot.melt(id_vars='index', var_name='Metric', value_name='Value')
    plt.figure(figsize=(10,12))
    sns.barplot(data=melted_df, x='index', y='Value', hue='Metric')
    
    # Set the x-axis labels
    plt.xticks(rotation='45',ha='right')

    # Set the y-axis label
    plt.ylabel('Value')

    # Set the chart title
    plt.title('Means and Standard Deviations of Personal Characteristics of All Participants')

    plt.savefig('means_sd_PCs_BarChart.png')
    # Show the plot
    plt.show()
    


def comparePC_Clusters_BarChart(): # Creating grouped boxplot of means of PCs in each cluster (Kunkel et. al)
    #plotDataFrame = pd.read_csv('mergedPC_Activities.csv')
    plotDataFrame = pd.read_csv('mergedPC_Activities_backup.csv')
    #print(plotDataFrame)
    #plotDataFrame = plotDataFrame.drop(columns=plotDataFrame[['stdUsername','hac_clusters','totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']],axis=1)
    plotDataFrame = plotDataFrame.drop(columns=['stdUsername','totalSessions','hac_clusters','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],axis=1)

    print(plotDataFrame)
    # Melt the DataFrame to combine the three activity columns into a single column
    melted_df = pd.melt(plotDataFrame, id_vars=['clusters'], value_vars=plotDataFrame.drop('clusters',axis=1), var_name='PC', value_name='Counts')
    print(melted_df)
    # Plotting
    plt.figure(figsize=(17,13))
    #plt.errorbar(x_values,plotDataFrame.drop('clusters',axis=1),yerr=std_value,fmt='none',color='black',capsize=4)
    #plt.annotate(f'Mean: {mean_value: .2f}',xy=(x_values.mean(),mean_value),xytext=(0,10),textcoords='offset points',ha='center',va='bottom',color='red')

    plt.title('Means (SD) of PCs in Engagement Clusters',fontsize=19)
    ax =sns.barplot(data=melted_df, x='PC', y='Counts', hue='clusters',capsize=0.1,errwidth=1)
    for p in ax.patches:
        ax.annotate(format(p.get_height(), '.2f'), (p.get_x() + p.get_width() / 2, p.get_height()), ha='center', va='bottom')
    #ax.errorbar(x=['PC'].index,y=means.value,yerr=std.value,fmt='none',color='black',capsize=4)
    plt.xticks(rotation='25',ha='right')
    plt.xlabel("Personal Characteristics",fontsize=15)
    plt.ylabel("Mean (SD)",fontsize=15)
    #plt.savefig('comparePC_Clusters_BarChart.png')
    plt.show()
    




    
#mergePC_Activities()
#comparePC_Clusters_BoxPlot()
#means_sd_PCs_BarChart()
comparePC_Clusters_BarChart()
#calculatePCPercentage()
