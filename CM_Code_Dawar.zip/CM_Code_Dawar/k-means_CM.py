import os
import pandas as pd
import matplotlib.pyplot as plt
#import OptimumClusters as oc
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans,AgglomerativeClustering
from sklearn.metrics import silhouette_score
#import correlation as cor
import seaborn as sns
import numpy as np



# df = pd.read_csv('output.csv',index_col='stdId')

## NOTE: Before dimentionality reduction, we have to scale data on a same scale. So, use data standardization (standard scaler) before PCA

#df=pd.read_csv('output.csv', usecols=['stdId','totalSessions','totalActivities','totalAnnotations'],index_col=0)
df=pd.read_csv('activitiesProduction.csv', usecols=['stdId','totalSessions','totalAccesses','pdfAccess','videoAccess','totalEnrollments','totalActivities','totalAnnotations','totalLikesOnAnnotations','likesOnRepliesOfAnnotations','totalDislikesOnAnnotations','dislikesOnRepliesOfAnnotations', 'videosStarted','videosCompleted','videosPlayed','videosPauses','pdfStarted','pdfCompleted','slidesViewed'],index_col=None)

print(df)

# remove NAN
#df.dropna(inplace=True)

# Scaling the data by choosing the columns we want to scale (Scalar Transform)
#print(df.describe())

scaler = StandardScaler()

df_normalized=scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])

#df[['totalSessions_T','totalActivities_T','totalAnnotations_T']]= scaler.fit_transform(df[['totalSessions','totalActivities','totalAnnotations']])
#print(df_normalized)
#print((df.describe()))

#oc.silhouetteScore(df_normalized,KMeans())

# Elbow method, selecting number of clusters
def optimise_k_means(data, max_k):
    means=[]
    inertias=[]
    for k in range(1,max_k):
        kmeans = KMeans(n_clusters=k)
        kmeans.fit(data)

        means.append(k)
        inertias.append(kmeans.inertia_)
    # Generate elbow plot
    fig = plt.subplots(figsize=(19,11))
    plt.plot(means,inertias,'o-')
    plt.xlabel('Number of Clusters',fontsize=20)
    plt.ylabel('Intertia / Sum of Squared Error',fontsize=20)
    plt.title('Elbow Method and Optimal Clusters',fontsize=25)
    plt.grid(True)
    plt.show()



def createBoxPlot():
    #plotDataFrame = pd.read_csv('activitiesProduction.csv', usecols=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'])
    plotDataFrame = pd.read_csv('mergedPC_Activities_backup.csv', usecols=['totalSessions','clusters','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'])
    
    #kmeans = KMeans(n_clusters=3)
    
    
    #kmeans.fit(plotDataFrame)
    #plotDataFrame['clusters'] = kmeans.labels_
    # Melt the DataFrame to combine the three activity columns into a single column
    melted_df = pd.melt(plotDataFrame, id_vars=['clusters'], value_vars=['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'], var_name='Activity', value_name='Counts')
#print(melted_df)
# Plotting

    plt.figure(figsize=(19,15))
    sns.boxplot(data=melted_df, x='Counts', y='Activity', hue='clusters')
    plt.xlabel("Counts")
    plt.ylabel("Activities")
    #plt.savefig('VerticalBoxPlotMeanOfFeaturesinCluster.png')
    plt.show()
    

def calculateFeaturesMeanPerCluster():
    df = pd.read_csv('mergedPC_Activities_backup.csv', usecols=['totalSessions','clusters','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'])
    #kmeans = KMeans(n_clusters=3)
    #scaler = StandardScaler()
    df_scaled= scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    #kmeans.fit(df_scaled)
    #df['cluster_labels'] = kmeans.labels_
    feature_means = np.mean(df,axis=0)
    grouped_data = df.groupby('clusters')
    print(grouped_data)
    group_means= grouped_data.mean()
    #print(group_means.to_csv('MeanOfFeaturesInCluster.csv'))
    group_std = grouped_data.std()
    #group_std.to_csv('StdOfFeaturesInCluster.csv')
    print(group_means)
    print(group_std)
   

def calculatePCMeanPerCluster():
    df = pd.read_csv('mergedPC_Activities.csv')
    print(df.columns)
    kmeans = KMeans(n_clusters=3)
    scaler = StandardScaler()
    df_scaled= scaler.fit_transform(df[['totalSessions','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed']])
    kmeans.fit(df_scaled)
    df['cluster_labels'] = kmeans.labels_
    newdf = df[['Level of Experience',
       'Tech saviness', 'Technical Knowledge of RS',
       'Visualization Familiarity', 'extraversion', 'agreeableness',
       'conscientiousness', 'Neuroticism', 'openness', 'NFC', 'LOC',
       'Rational DMS', 'Intutive DMS','cluster_labels']]


    pcdf_gr = newdf.groupby('cluster_labels')

    f_c= ['Level of Experience',
       'Tech saviness', 'Technical Knowledge of RS',
       'Visualization Familiarity', 'extraversion', 'agreeableness',
       'conscientiousness', 'Neuroticism', 'openness', 'NFC', 'LOC',
       'Rational DMS', 'Intutive DMS']
    features = pcdf_gr[f_c]
    mean_values = features.mean()
    std_values = features.std()
    print(mean_values)
    print(std_values)
    #print(grouped_data)
    #group_means= grouped_data.mean()
    #group_sd = grouped_data.std()
    #group_means.to_csv('Mean_PCPerCluster.csv')
    #group_sd.to_csv('Std_PCperCluster.csv')
    #print(group_means)
    #print(group_sd)


def createIndividualFeatureBoxPlot():
    plotDataFrame = pd.read_csv('mergedPC_Activities_backup.csv', usecols=['totalSessions','clusters','totalEnrollments','totalActivities', 'totalAnnotations', 'totalLikesOnAnnotations', 'totalAccesses','videosStarted','videosPauses','pdfStarted','pdfCompleted','slidesViewed'])
    folderpath = 'plots_4/'
    #kmeans = KMeans(n_clusters=3)
    #kmeans.fit(df_normalized)
    #plotDataFrame['clusters'] = kmeans.labels_
    #print(plotDataFrame)
    if not os.path.exists(folderpath):
        os.makedirs(folderpath)
    for column in plotDataFrame.columns:
        melted_df = pd.melt(plotDataFrame, id_vars=['clusters'], value_vars=column, var_name='Activity', value_name='Counts')
        print(melted_df)
        # Plotting
        sns.boxplot(data=melted_df, x='Activity', y='Counts', hue='clusters')

        plt.ylabel("Counts")
        plt.title('Comparison between {} in Clusters'.format(column))
        
        plt.savefig('plots_4/{}.png'.format(column))
        plt.show() 
        


def calculatePCPercentage():
    df = pd.read_csv('PC Categorized_clusterized.csv',index_col=None)
    df = df.drop(columns=df[['stdUsername','hac_clusters']],axis=1)
    print(df)
    groupedDf = df.groupby('clusters')
    print(groupedDf)
# Here we will have to use dimensionality reduction to convert multidimentional data to 2D, since scatter plot is 2D
#optimise_k_means(df[['totalSessions_T','totalActivities_T','totalAnnotations_T']],10)

#optimise_k_means(df.drop(['stdId'],axis=1),10)
#optimise_k_means(df_normalized,10)
#createBoxPlot()
calculateFeaturesMeanPerCluster()
#calculatePCMeanPerCluster()
#createIndividualFeatureBoxPlot()
#calculatePCPercentage()



# Applying KMeans
#kmeans = KMeans(n_clusters=2)
#kmeans.fit(df[['totalSessions_T','totalAnnotations_T']])
#print(df.describe())

# kmeans.labels_ are the labels of clusters to which each datapoint belongs
#df['kmeans_3']=kmeans.labels_
#print(df)# Plot the clustering reults

""" plt.scatter(x=df['totalAnnotations_T'],y=df['totalSessions_T'],c=df['kmeans_3'])
plt.xlim(-2,5)
plt.ylim(-2,5)
plt.show()


oc.silhouetteScore(df,KMeans())
oc.calinskiScore(df, kmeans.labels_)
print(silhouette_score(df, kmeans.labels_)) 
oc.silhouetteScore(df_normalized,AgglomerativeClustering(linkage='ward')) """




'''
# Comparing different K values

for k in range(1,6):
    kmeans=KMeans(n_clusters=k)
    kmeans.fit(df[['RHOB_T','NPHI_T']])
    df[f'KMeans_{k}'] = kmeans.labels_

#df
fig, axs = plt.subplots(nrows=1,ncols=5,figsize=(20,5))

for i, ax in enumerate(fig.axes,start=1):
    ax.scatter(x=df['NPHI'],y=df['RHOB'],c=df[f'KMeans_{i}'])
    ax.set_ylim(3,1.5)
    ax.set_xlim(0,1)
    ax.set_title(f'N Clusters: {i}') 
    
cor.correlation_matrix(df[['RHOB_T','NPHI_T','GR_T','PEF_T','DTC_T']])

cor.correlation_matrix(df[['RHOB','NPHI','GR','PEF','DTC']])'''


