Description of files step by step in order of processing:
starts from main.py:
Main.py - connects to local database (mongodb) and fetches the "activitiesProduction" collection from the database (This collection was exported from the deployed version of CourseMapper by Shoeb Joarder)
DataProcessing.py - Python file that create student profiles which is a collected of all the activities performed by te students. Student activities in Activities production file is a whole list of activities performed by different students. those activities are aggregated as a set of activities of each student in a JSON File (ActivitiesProduction.JSON)
ActivitiesProduction - JSON File contains CM users' activities collected from CourseMapper deployed and used by students
populateStudentProfiles.py - This python file generates a csv file - converts xAPI statements to csv files and populates the columns (activities)

OptimumClusters.py - Python file used to find optimal number of cluster for K Means and HAC using different techniques to find optimal clusters e.g Elbow method, Silhouette Coefficient etc

k_Means_CM.py - Python file which applies clustering techniques on the profile of students, Plots and visualisations were also created in this file. Means and Standard deviatiion between features (activities) and PCs were also calculated here.

TSNE.py - Applying feature reduction technique (tSNE) on our features. The applying both KM and HAC on reduced features (dimensions). In this file, the silhouette scores are also calculated again on the reduced dimension, for both KM and HAC

Correlation - Python files calculates correlation between activities-activites, PCs-PCs and activities-PCs
