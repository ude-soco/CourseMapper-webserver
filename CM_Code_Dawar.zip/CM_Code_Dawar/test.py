import matplotlib.pyplot as plt
import pandas as pd

# Assuming you have a DataFrame called 'df' with the required data

# Group the data by the 'cluster' column and calculate the counts of each feature
grouped_data = df.groupby('cluster')[['feature1', 'feature2', 'feature3']].count()

# Calculate the percentages of 'feature3' within each cluster
percentages = df.groupby('cluster')['feature3'].value_counts(normalize=True).unstack()

# Create a stacked bar chart
grouped_data.plot(kind='bar', stacked=True)

# Add the percentage labels to each stacked bar
for i, cluster in enumerate(grouped_data.index):
    total = grouped_data.loc[cluster].sum()
    for j, col in enumerate(grouped_data.columns):
        percentage = percentages.loc[cluster, col] * 100
        plt.text(i, grouped_data.loc[cluster, col]/2, f'{percentage:.1f}%', ha='center', va='center')

# Customize the plot
plt.xlabel('Cluster')
plt.ylabel('Count')
plt.title('Grouped Stacked Bar Chart')
plt.legend(title='Features', loc='upper right')
plt.xticks(range(len(grouped_data.index)), grouped_data.index)

# Display the plot
plt.show()